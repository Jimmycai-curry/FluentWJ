# 登录页面功能规范

## Spec 概述
本规范描述 FluentWJ 登录页面的前端组件实现和功能逻辑。

**文档版本**: v1.0
**创建日期**: 2025-01-13
**相关 PRD**: `/docs/prd/[PRD] FluentWJ 跨境商务写作助手项目需求文档.md`
**相关组件**:
- `app/(auth)/layout.tsx`
- `app/(auth)/login/page.tsx`
- `components/auth/LoginForm.tsx`
- `utils/validation.ts`

---

## 功能描述

登录页面是用户进入 FluentWJ 系统的唯一入口，支持两种登录方式：

1. **验证码登录**（默认）：通过手机号 + 短信验证码登录
2. **密码登录**：通过手机号 + 密码登录

### 核心功能
- Tab 切换：在验证码登录和密码登录之间切换
- 手机号输入：支持中国大陆手机号（+86）
- 验证码获取：60秒倒计时功能
- 密码可见性切换：点击图标显示/隐藏密码
- 协议勾选：必须同意服务协议和隐私政策才能提交
- 深色模式：支持浅色/深色主题切换
- 响应式布局：适配桌面和移动端

---

## 功能逻辑

### 登录流程（当前阶段：仅 UI）

```
用户访问 /login
  ↓
显示登录表单（默认验证码登录 Tab）
  ↓
用户输入手机号
  ↓
[验证码模式]                [密码模式]
  ↓                           ↓
点击"获取验证码"            输入密码
  ↓                           ↓
输入验证码                  点击"忘记密码"（可选）
  ↓                           ↓
勾选协议                    勾选协议
  ↓                           ↓
点击"登录"按钮              点击"登录"按钮
  ↓                           ↓
前端表单验证                前端表单验证
  ↓                           ↓
[TODO: 后续阶段]
调用 API 接口
  ↓
验证成功 → 跳转到 /dashboard
验证失败 → 显示错误提示
```

---

## 接口定义

### 1. 数据类型定义

```typescript
// 登录模式
type LoginMode = 'code' | 'password';

// 表单数据接口
interface LoginFormData {
  phone: string;          // 手机号（11位数字）
  code?: string;          // 验证码（验证码登录时使用）
  password?: string;      // 密码（密码登录时使用）
  agreed: boolean;        // 是否同意协议
}

// 表单错误接口
interface LoginFormErrors {
  phone?: string;
  code?: string;
  password?: string;
  agreed?: string;
}

// 验证结果接口
interface ValidationResult {
  isValid: boolean;
  error?: string;
}
```

### 2. 组件 Props 接口

```typescript
// LoginForm 组件 Props
interface LoginFormProps {
  onSubmit?: (data: LoginFormData, mode: LoginMode) => void;
  onGetCode?: (phone: string) => Promise<void>;
  isLoading?: boolean;
}
```

### 3. API 接口（后续阶段）

```typescript
// POST /api/auth/send-code
interface SendCodeRequest {
  phone: string;
}

interface SendCodeResponse {
  success: boolean;
  message: string;
  cooldown?: number;  // 剩余冷却时间（秒）
}

// POST /api/auth/login
interface LoginRequest {
  phone: string;
  code?: string;
  password?: string;
}

interface LoginResponse {
  success: boolean;
  message: string;
  user?: {
    id: string;
    phone: string;
    role: number;
  };
  token?: string;
}
```

---

## UI 交互逻辑

### 1. Tab 切换

**初始状态**：
- 默认激活"验证码登录" Tab
- 验证码输入框可见，密码输入框隐藏

**切换行为**：
- 点击 Tab 按钮切换模式
- 激活的 Tab 显示底部蓝色下划线（2px）
- 切换时保留手机号输入值
- 切换时清空验证码/密码输入值

**实现细节**：
```typescript
const [loginMode, setLoginMode] = useState<LoginMode>('code');

const switchTab = (mode: LoginMode) => {
  setLoginMode(mode);
  // 保留手机号，清空验证码和密码
  setFormData(prev => ({
    ...prev,
    code: '',
    password: ''
  }));
};
```

---

### 2. 手机号输入

**输入框特性**：
- 前缀显示：`+86`（固定，不可修改）
- 占位符：`请输入手机号`
- 图标：右侧显示手机图标（`smartphone`）
- 输入限制：仅允许数字，最多 11 位

**实时验证**：
- 长度不足 11 位：无错误提示
- 长度达到 11 位：自动验证格式
- 格式错误：输入框下方显示红色错误提示

**验证规则**：
```typescript
// 中国大陆手机号正则
const PHONE_REGEX = /^1[3-9]\d{9}$/;

function validatePhone(phone: string): ValidationResult {
  if (!phone) {
    return { isValid: false, error: '请输入手机号' };
  }
  if (phone.length !== 11) {
    return { isValid: false, error: '手机号必须为11位' };
  }
  if (!PHONE_REGEX.test(phone)) {
    return { isValid: false, error: '请输入正确的手机号格式' };
  }
  return { isValid: true };
}
```

---

### 3. 验证码获取（验证码登录模式）

**按钮位置**：
- 嵌入在验证码输入框右侧
- 最小宽度：`100px`
- 样式：透明背景 + 蓝色文字

**按钮状态**：

| 状态 | 显示文本 | 可点击 | 样式 |
|------|---------|--------|------|
| 默认 | "获取验证码" | ✅ | 蓝色文字 |
| 倒计时中 | "60s 后重新获取" | ❌ | 灰色文字 |
| 手机号未填写 | "获取验证码" | ❌ | 灰色文字（disabled） |
| 手机号格式错误 | "获取验证码" | ❌ | 灰色文字（disabled） |

**倒计时逻辑**：
```typescript
const [countdown, setCountdown] = useState(0);
const [isGettingCode, setIsGettingCode] = useState(false);

const handleGetCode = async () => {
  // 验证手机号
  const validation = validatePhone(formData.phone);
  if (!validation.isValid) {
    toast.error(validation.error);
    return;
  }

  setIsGettingCode(true);
  
  // TODO: 调用发送验证码 API
  // await sendVerificationCode(formData.phone);
  
  // 启动 60 秒倒计时
  setCountdown(60);
  const timer = setInterval(() => {
    setCountdown(prev => {
      if (prev <= 1) {
        clearInterval(timer);
        setIsGettingCode(false);
        return 0;
      }
      return prev - 1;
    });
  }, 1000);

  // 模拟成功提示
  toast.success('验证码已发送');
};
```

---

### 4. 密码输入（密码登录模式）

**输入框特性**：
- 占位符：`请输入密码`
- 类型：`password`（默认隐藏）
- 图标：右侧显示锁图标（`lock`）

**密码可见性切换**：
- 点击右侧图标切换显示/隐藏
- 显示时：`type="text"`，图标变为 `visibility_off`
- 隐藏时：`type="password"`，图标为 `visibility`

**忘记密码链接**：
- 位置：密码输入框标签右侧
- 文字：`忘记密码？`
- 样式：蓝色文字 + hover 下划线
- 行为：跳转到 `/forgot-password`（待实现）

---

### 5. 协议勾选

**必选验证**：
- 登录按钮默认可点击
- 提交时检查协议是否勾选
- 未勾选时显示错误提示：`请先阅读并同意服务协议`

**链接跳转**：
- "服务协议" → `/terms`（待创建）
- "隐私政策" → `/privacy`（待创建）
- 新标签页打开

---

### 6. 登录按钮

**按钮状态**：
- 默认：蓝色背景 + 白色文字
- Hover：`bg-primary/90`
- 点击：`scale-[0.98]`（轻微缩小动画）
- Loading：显示加载动画（后续实现）

**提交验证**：
```typescript
const handleSubmit = (e: FormEvent) => {
  e.preventDefault();
  
  // 1. 验证手机号
  const phoneValidation = validatePhone(formData.phone);
  if (!phoneValidation.isValid) {
    toast.error(phoneValidation.error);
    return;
  }

  // 2. 验证验证码/密码
  if (loginMode === 'code') {
    if (!formData.code) {
      toast.error('请输入验证码');
      return;
    }
    if (formData.code.length !== 6) {
      toast.error('验证码必须为6位数字');
      return;
    }
  } else {
    if (!formData.password) {
      toast.error('请输入密码');
      return;
    }
    if (formData.password.length < 6) {
      toast.error('密码长度不能少于6位');
      return;
    }
  }

  // 3. 验证协议勾选
  if (!formData.agreed) {
    toast.error('请先阅读并同意服务协议');
    return;
  }

  // TODO: 调用登录 API
  console.log('登录数据:', formData);
  toast.success('登录成功（演示）');
  router.push('/dashboard');
};
```

---

### 7. 深色模式切换

**切换按钮**：
- 位置：页面右上角（绝对定位）
- 样式：圆形按钮 + 月亮图标
- 行为：切换 `html` 标签的 `class="dark"`

**实现方式**：
```typescript
<button 
  onClick={() => {
    document.documentElement.classList.toggle('dark');
    // 保存到 localStorage
    const isDark = document.documentElement.classList.contains('dark');
    localStorage.setItem('theme', isDark ? 'dark' : 'light');
  }}
  className="fixed top-8 right-8 flex h-10 w-10 items-center justify-center rounded-full bg-white dark:bg-white/10 shadow-sm dark:text-white transition-colors"
>
  <span className="material-symbols-outlined text-[20px]">dark_mode</span>
</button>
```

---

## 设计规范

### 1. 颜色系统

**品牌色**：
- Primary: `#0052D9`（蓝色，用于按钮、链接、激活状态）

**背景色**：
- 浅色模式：`#f5f5f8`（页面背景）
- 深色模式：`#0f0f23`（页面背景）
- 表单容器：`white` / `dark:bg-background-dark/50`

**文字颜色**：
- 主文字：`#0c0c1d` / `dark:white`
- 次级文字：`#4545a1` / `dark:white/60`
- 占位符：`#4545a1/60` / `dark:white/30`

**边框颜色**：
- 输入框：`#cdcdea` / `dark:white/20`
- Tab 分隔线：`#cdcdea` / `dark:white/10`

---

### 2. 字体规范

**字体家族**：
```css
font-family: 'Inter', 'PingFang SC', 'Microsoft YaHei', sans-serif;
```

**字号**：
- 页面标题（"FluentWJ"）：`text-2xl` (24px)
- 表单标题（"登录 FluentWJ"）：`text-[28px]` (28px)
- Tab 标签：`text-sm` (14px)
- 输入框标签：`text-base font-medium` (16px)
- 输入框内容：`text-base` (16px)
- 按钮文字：`text-base font-bold` (16px)
- 协议文字：`text-sm` (14px)
- Footer 文字：`text-xs` (12px)

---

### 3. 间距规范

**表单容器**：
- 最大宽度：`max-w-[440px]`
- 内边距：`p-8` (32px)
- 圆角：`rounded-xl` (12px)
- 阴影：`shadow-xl`

**表单元素间距**：
- 表单整体：`space-y-6` (24px)
- Tab 与表单：`mb-8` (32px)
- 输入框高度：`h-14` (56px)
- 按钮高度：`h-14` (56px)

**输入框内部**：
- 横向内边距：`p-[15px]`
- 前缀（+86）：`pl-4 pr-2`
- 图标右边距：`pr-[15px]`

---

### 4. 圆角规范

**Tailwind 配置**：
```typescript
borderRadius: {
  "DEFAULT": "0.25rem",  // 4px
  "lg": "0.5rem",        // 8px
  "xl": "0.75rem",       // 12px
  "full": "9999px"       // 完全圆形
}
```

**应用**：
- Logo 容器：`rounded-lg`
- 输入框：`rounded-lg`
- 按钮：`rounded-lg`
- 表单容器：`rounded-xl`
- 主题切换按钮：`rounded-full`

---

### 5. 阴影规范

**表单容器**：
```css
box-shadow: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);
```

**登录按钮**：
```css
box-shadow: 0 10px 15px -3px rgb(5 82 217 / 0.2);
```

---

### 6. 图标系统

**使用 Material Symbols Outlined**：
- 邮件图标：`mail`
- 手机图标：`smartphone`
- 锁图标：`lock`
- 可见性：`visibility` / `visibility_off`
- 深色模式：`dark_mode`

**加载方式**：
```html
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet"/>
```

---

## 页面结构

```
┌─────────────────────────────────────────────────────────┐
│  [深色模式切换按钮]                                       │
│                                                         │
│                    [Logo] FluentWJ                      │
│                                                         │
│  ┌───────────────────────────────────────────────────┐ │
│  │           登录 FluentWJ                            │ │
│  │                                                   │ │
│  │  [验证码登录 Tab] │ [密码登录 Tab]                │ │
│  │  ─────────────────                                │ │
│  │                                                   │ │
│  │  手机号                                           │ │
│  │  [+86] [_________________] 📱                     │ │
│  │                                                   │ │
│  │  验证码 / 密码                [忘记密码?]          │ │
│  │  [_________________] [获取验证码] / 🔒            │ │
│  │                                                   │ │
│  │  [  登 录  ]                                      │ │
│  │                                                   │ │
│  │  ☑ 我已阅读并同意 服务协议 和 隐私政策            │ │
│  └───────────────────────────────────────────────────┘ │
│                                                         │
│  © 2024 FluentWJ AI Writing Assistant                  │
│  粤ICP备2023000000号-1  |  AI 算法备案号: 440300...     │
└─────────────────────────────────────────────────────────┘
```

---

## 涉及的 DB 变更

### 相关数据表

**users 表** (`prisma/schema.prisma`)：
```prisma
model users {
  id              String    @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  phone           String    @unique @db.VarChar(20)
  password_hash   String
  role            Int?      @default(1) @db.SmallInt
  status          Int?      @default(1) @db.SmallInt
  last_login_ip   String?   @db.VarChar(45)
  last_login_time DateTime? @db.Timestamptz(6)
  created_time    DateTime? @default(now()) @db.Timestamptz(6)
  updated_time    DateTime? @default(now()) @db.Timestamptz(6)
}
```

### 后续数据库操作（API 阶段）

1. **验证码登录**：
   - 查询 `users` 表，根据 `phone` 查找用户
   - 如果不存在，自动创建新用户（`password_hash` 为空）
   - 更新 `last_login_ip` 和 `last_login_time`

2. **密码登录**：
   - 查询 `users` 表，根据 `phone` 查找用户
   - 验证 `password_hash`（使用 bcrypt）
   - 更新 `last_login_ip` 和 `last_login_time`

3. **审计日志**：
   - 每次登录尝试记录到 `admin_operation_logs` 或创建新表 `login_logs`

---

## 异常处理

### 1. 客户端验证错误

| 场景 | 错误提示 | 显示方式 |
|------|---------|---------|
| 手机号为空 | "请输入手机号" | Toast 提示 |
| 手机号格式错误 | "请输入正确的手机号格式" | Toast 提示 |
| 验证码为空 | "请输入验证码" | Toast 提示 |
| 验证码长度错误 | "验证码必须为6位数字" | Toast 提示 |
| 密码为空 | "请输入密码" | Toast 提示 |
| 密码长度不足 | "密码长度不能少于6位" | Toast 提示 |
| 未勾选协议 | "请先阅读并同意服务协议" | Toast 提示 |

### 2. 服务端错误（后续实现）

| 场景 | HTTP 状态码 | 错误提示 |
|------|------------|---------|
| 验证码错误 | 400 | "验证码错误，请重新输入" |
| 验证码过期 | 400 | "验证码已过期，请重新获取" |
| 密码错误 | 401 | "手机号或密码错误" |
| 用户被封禁 | 403 | "您的账户已被封禁，请联系管理员" |
| 发送频繁 | 429 | "操作过于频繁，请稍后再试" |
| 服务器错误 | 500 | "系统繁忙，请稍后再试" |

### 3. 网络错误

| 场景 | 错误提示 |
|------|---------|
| 请求超时 | "网络连接超时，请检查网络" |
| 网络中断 | "网络连接失败，请检查网络设置" |

---

## 后续扩展

### 第二阶段：API 集成
1. 集成华为云 SMS 服务发送验证码
2. 实现 `/api/auth/send-code` 接口
3. 实现 `/api/auth/login` 接口（验证码 + 密码）
4. 集成 NextAuth.js 进行会话管理

### 第三阶段：完善功能
1. 实现"忘记密码"流程
2. 添加图形验证码防止机器人
3. 实现登录失败次数限制
4. 添加第三方登录（微信、企业微信）

### 第四阶段：合规增强
1. 记录登录审计日志（IP、设备、时间）
2. 异地登录提醒
3. 实名认证流程
4. 账号安全中心

---

## 验收标准

### UI 还原度
- [ ] Logo 和标题居中显示
- [ ] 表单容器圆角、阴影效果正确
- [ ] Tab 下划线动画（active 状态）
- [ ] 输入框的 focus 状态（蓝色 ring）
- [ ] 验证码按钮在输入框内部右侧
- [ ] 深色模式切换按钮位于右上角
- [ ] Footer 版权信息和备案号正确显示
- [ ] Material Icons 正确加载

### 功能完整性
- [ ] Tab 切换正常工作
- [ ] 手机号格式验证正确
- [ ] 验证码倒计时功能正常
- [ ] 密码可见性切换正常
- [ ] 协议勾选验证正常
- [ ] 深色模式切换正常
- [ ] 响应式布局正常

### 代码质量
- [ ] 代码符合项目命名规范
- [ ] 所有文件包含规范头部注释
- [ ] 核心逻辑包含中文注释
- [ ] 无 TypeScript 错误
- [ ] 无 ESLint 警告

### 用户体验
- [ ] 表单验证提示清晰
- [ ] 按钮状态反馈明显
- [ ] 页面加载流畅无卡顿
- [ ] 动画过渡自然
- [ ] 移动端触摸体验良好

---

---

## 后端实现规范

### 1. 登录 API 接口规范

**文件路径**: `app/api/auth/login/route.ts`

**功能**: 提供验证码登录和密码登录接口，返回安全的 Cookie

#### 接口定义

```typescript
// POST /api/auth/login
interface LoginRequest {
  phone: string;       // 手机号（11位数字）
  code?: string;       // 验证码（验证码登录时使用）
  password?: string;   // 密码（密码登录时使用）
  mode: 'code' | 'password';  // 登录模式
}

interface LoginResponse {
  success: boolean;
  message: string;
  user?: {
    id: string;
    phone: string;
    role: number;
  };
  token?: string;                    // JWT Token
  needsPasswordSetup?: boolean;      // 是否需要设置密码（首次验证码登录）
}
```

#### Cookie 安全配置（必须）

登录成功后必须设置安全的 HttpOnly Cookie：

```typescript
response.cookies.set('auth_token', result.token, {
  httpOnly: true,  // 禁止 JavaScript 读取 Cookie，防止 XSS 攻击
  secure: process.env.NODE_ENV === 'production',  // 生产环境必须使用 HTTPS
  sameSite: 'strict',  // 防止 CSRF 攻击
  maxAge: 60 * 60 * 24,  // 1 天有效期（与 JWT 过期时间一致）
  path: '/',  // 在整个域名下有效
})
```

**安全特性说明**:
- `httpOnly: true` - JavaScript 无法读取 Cookie，防止 XSS 攻击窃取 Token
- `secure: true` - 生产环境强制 HTTPS 传输，防止中间人攻击
- `sameSite: 'strict'` - 防止 CSRF 跨站请求伪造攻击

#### 验证流程

1. **参数验证**
   - 检查手机号格式（1开头，第二位3-9，共11位）
   - 检查验证码格式（6位数字）或密码格式（6-20位）
   - 检查登录模式是否有效

2. **业务逻辑**
   - 验证码登录：验证 Redis 中的验证码，验证失败抛出 `UnauthorizedError`
   - 密码登录：使用 bcrypt 验证密码哈希，验证失败抛出 `UnauthorizedError`
   - 用户不存在：抛出 `UnauthorizedError`（统一错误提示）
   - 用户状态检查：验证用户是否被封禁，被封禁抛出 `ForbiddenError`

3. **登录成功**
   - 生成 JWT Token（包含 userId, phone, role）
   - 设置 HttpOnly Cookie
   - 更新用户登录信息（last_login_ip, last_login_time）
   - 返回用户信息和 Token

#### 错误处理

所有错误必须通过 `withErrorHandler` 包装，返回统一的 JSON 格式：

```typescript
{
  success: false,
  message: '错误描述',
  error: {
    code: 'ERROR_CODE',
    details?: '详细错误信息（仅开发环境）'
  }
}
```

---

### 2. 中间件（Middleware）规范

**文件路径**: `middleware.ts`

**功能**: 保护路由，验证用户登录状态

#### 路由分类

```typescript
// 受保护的路由列表（需要登录才能访问）
const PROTECTED_ROUTES = ['/dashboard', '/settings']

// 公开的路由列表（无需登录即可访问）
const PUBLIC_ROUTES = ['/login', '/set-password']
```

#### 验证逻辑

```typescript
export async function middleware(request: NextRequest) {
  const { pathname } = new URL(request.url)

  // 1. 统一获取 Token，避免重复代码
  const token = request.cookies.get('auth_token')?.value

  // 2. 公开路由直接放行，不检查 Token
  if (PUBLIC_ROUTES.some(route => pathname.startsWith(route))) {
    return NextResponse.next()
  }

  // 3. 受保护路由需要验证 Token
  if (PROTECTED_ROUTES.some(route => pathname.startsWith(route))) {
    if (!token) {
      // 未登录，重定向到登录页，并保存原始路径
      const url = new URL('/login', request.url)
      url.searchParams.set('redirect', pathname)
      return NextResponse.redirect(url)
    }

    // 验证 Token 有效性
    const payload = await verifyToken(token)
    if (!payload) {
      // Token 无效或过期，重定向到登录页
      const url = new URL('/login', request.url)
      url.searchParams.set('redirect', pathname)
      return NextResponse.redirect(url)
    }

    // Token 有效，允许访问
    return NextResponse.next()
  }

  // 4. 根路由处理：已登录用户跳转到 Dashboard
  if (pathname === '/') {
    if (token) {
      const payload = await verifyToken(token)
      if (payload) {
        return NextResponse.redirect(new URL('/dashboard', request.url))
      }
    }
  }

  // 5. 其他情况放行
  return NextResponse.next()
}
```

**注意事项**:
- Token 只获取一次，避免重复代码
- 受保护路由必须验证 Token 有效性
- 公开路由（如 `/set-password`）不检查 Token
- 重定向时保留原始路径（redirect 参数）

---

### 3. 设置密码接口规范

**文件路径**: `app/api/auth/set-password/route.ts`

**功能**: 首次登录后设置密码，设置成功后直接进入 dashboard

#### 接口定义

```typescript
// POST /api/auth/set-password
// 需要认证：Bearer Token（来自登录接口返回的 Token）
interface SetPasswordRequest {
  password: string;        // 新密码（6-20位）
  confirmPassword: string;  // 确认密码
}

interface SetPasswordResponse {
  success: boolean;
  message: string;
}
```

#### 业务逻辑

1. **Token 验证**
   - 从 `Authorization` 头获取 Token（格式：`Bearer xxx`）
   - 验证 Token 有效性
   - Token 无效或过期返回 401

2. **参数验证**
   - 检查密码和确认密码是否为空
   - 检查密码长度（6-20位）
   - 检查两次密码是否一致

3. **密码设置**
   - 调用 `setPasswordAfterLogin` Service
   - 使用 bcrypt 加密密码（salt=10）
   - 更新数据库中的 `password_hash` 字段

4. **登录保持**
   - 设置密码后，用户 Token 仍然有效
   - 前端清除 localStorage 中的旧 Token（现在使用 Cookie）
   - 直接跳转到 `/dashboard`，不需要重新登录

#### 前端处理

```typescript
// app/(auth)/set-password/page.tsx
if (result.success) {
  // 设置密码成功后，清除 localStorage
  localStorage.removeItem("auth_token");
  // 直接跳转到 dashboard，不需要重新登录
  router.push("/dashboard");
} else {
  alert(result.message || "设置密码失败");
}
```

**重要**: 设置密码后**不需要**重新登录，因为用户已经处于登录状态。

---

### 4. 登录流程完整图

```
┌─────────────────────────────────────────────────────────────┐
│  用户访问登录页面                                           │
└─────────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────────┐
│  选择登录模式：验证码登录 / 密码登录                       │
└─────────────────────────────────────────────────────────────┘
                          ↓
              ┌─────────────┴─────────────┐
              ↓                           ↓
    验证码登录流程                 密码登录流程
              ↓                           ↓
    1. 输入手机号                1. 输入手机号
    2. 点击"获取验证码"            2. 输入密码
    3. 输入验证码                3. 点击"登录"
    4. 点击"登录"
              ↓                           ↓
    ┌─────────────┴─────────────┐
              ↓
    调用 POST /api/auth/login
              ↓
    ┌─────────────────────────────┐
    │  后端验证逻辑              │
    └─────────────────────────────┘
              ↓
    ┌─────────────┬─────────────┐
    ↓                           ↓
验证码登录                  密码登录
    ↓                           ↓
- 验证 Redis 验证码          - 验证密码哈希
- 查询/创建用户              - 查询用户
- 检查用户状态              - 检查用户状态
- 生成 JWT Token             - 生成 JWT Token
- 设置 HttpOnly Cookie       - 设置 HttpOnly Cookie
- 更新登录信息              - 更新登录信息
              ↓                           ↓
              └─────────────┬─────────────┘
                          ↓
              ┌─────────────────────────────┐
              │  返回登录成功响应          │
              │  { success, user, token }  │
              └─────────────────────────────┘
                          ↓
              ┌─────────────────────────────┐
              │  判断是否需要设置密码       │
              │  needsPasswordSetup?       │
              └─────────────────────────────┘
                    ↓           ↓
                 YES           NO
                    ↓           ↓
        跳转到 /set-password  跳转到 /dashboard
                    ↓
        输入新密码和确认密码
                    ↓
        调用 POST /api/auth/set-password
                    ↓
        验证 Token（已登录）
                    ↓
        设置密码（bcrypt 加密）
                    ↓
        密码设置成功
                    ↓
        清除 localStorage（旧 Token）
                    ↓
        跳转到 /dashboard ✓
```

---

### 5. 安全规范总结

#### Cookie 安全（必须遵守）

| 配置项 | 值 | 作用 |
|--------|-----|------|
| httpOnly | true | 防止 XSS 攻击窃取 Token |
| secure | true (生产) | 强制 HTTPS 传输 |
| sameSite | strict | 防止 CSRF 跨站请求伪造 |
| maxAge | 86400 (1天) | Token 有效期 |
| path | / | 全站有效 |

#### JWT Token 安全

- 使用 `HS256` 算法签名
- Payload 包含：userId, phone, role
- Secret 至少 32 字符
- 过期时间：1 天

#### 密码安全

- 使用 bcrypt 加密（salt=10）
- 密码长度：6-20 位
- 不在日志中记录明文密码
- 密码错误返回统一提示："手机号或密码错误"

#### 验证码安全

- 6 位数字随机验证码
- 有效期：5 分钟（Redis TTL=300）
- 冷却时间：60 秒
- 每日限制：10 次
- 使用后立即删除（一次性）

---

### 6. 错误码规范

| 错误码 | HTTP 状态 | 场景 | 提示信息 |
|--------|-----------|------|---------|
| VALIDATION_ERROR | 400 | 参数验证失败 | 具体字段错误提示 |
| UNAUTHORIZED | 401 | 未授权访问 | "手机号或密码错误" / "验证码错误或已过期" |
| FORBIDDEN | 403 | 用户被封禁 | "您的账户已被封禁，请联系管理员" |
| NOT_FOUND | 404 | 资源不存在 | "用户不存在" |
| RATE_LIMIT | 429 | 请求过于频繁 | "操作过于频繁，请稍后再试" |
| INTERNAL_SERVER_ERROR | 500 | 服务器错误 | "系统繁忙，请稍后再试" |

---

**最后更新**: 2025-01-15
**更新内容**: 添加完整的登录后端规范，包括 API、Middleware、设置密码流程
